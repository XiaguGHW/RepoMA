"""Safe, coordinate-accurate Excel assistant for Bosch Farm terminal workflows.

The program never lets an LLM guess an Excel address.  It first reads the workbook
with openpyxl, exposes exact A1 coordinates/formulas, creates a JSON edit plan, and
only writes that reviewed plan to a *new* output workbook.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import uuid
import re
import sys
from copy import copy
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from openpyxl.formula.tokenizer import Tokenizer
from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.utils.cell import range_boundaries
from openpyxl.worksheet.formula import ArrayFormula, DataTableFormula


SPECIAL_FORMULAS = (ArrayFormula, DataTableFormula)


def excel_json_value(value: Any) -> Any:
    """Keep formula definitions and Excel types meaningful at the JSON boundary."""
    if isinstance(value, ArrayFormula):
        return {"type": "array_formula", "text": value.text, "ref": value.ref}
    if isinstance(value, DataTableFormula):
        return {"type": "data_table_formula", **dict(value)}
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if isinstance(value, timedelta):
        return {"type": "duration", "seconds": value.total_seconds()}
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    raise TypeError(f"Unsupported Excel value type: {type(value).__name__}")


def stored_cells(sheet):
    # Normal (non-read-only) worksheets retain sparse cells in _cells. Avoid
    # iter_rows(), which expands a formatted 1,048,576-row sheet into blank cells.
    return (cell for _, cell in sorted(sheet._cells.items()))


def special_formula_ranges(sheet) -> list[tuple]:
    definitions = []
    for cell in stored_cells(sheet):
        if isinstance(cell.value, SPECIAL_FORMULAS) and cell.value.ref:
            definitions.append((cell.coordinate, range_boundaries(cell.value.ref), cell.value))
    return definitions


def cell_record(cell, definitions: list[tuple] | None = None) -> dict[str, Any]:
    """Exact stored value plus the formula owner for an array/table result cell."""
    value = cell.value
    record = {"cell": f"{cell.parent.title}!{cell.coordinate}", "value": excel_json_value(value),
              "formula": None, "value_type": type(value).__name__}
    if isinstance(value, str) and value.startswith("=") and cell.data_type == "f":
        record.update(formula=value, formula_type="normal")
        return record
    definitions = special_formula_ranges(cell.parent) if definitions is None else definitions
    for anchor, bounds, definition in definitions:
        min_col, min_row, max_col, max_row = bounds
        if min_col <= cell.column <= max_col and min_row <= cell.row <= max_row:
            record.update(
                formula=getattr(definition, "text", None),
                formula_type="array" if isinstance(definition, ArrayFormula) else "data_table",
                formula_anchor=f"{cell.parent.title}!{anchor}", formula_range=definition.ref,
                is_formula_anchor=cell.coordinate == anchor,
                formula_definition=excel_json_value(definition),
            )
            break
    return record


def die(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(2)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def formula_fingerprint(book) -> dict[str, Any]:
    """Return a stable workbook-wide checksum of formula text and locations."""
    digest = hashlib.sha256()
    count = 0
    for sheet in book.worksheets:
        for cell in stored_cells(sheet):
            value = cell.value
            if isinstance(value, SPECIAL_FORMULAS):
                value = json.dumps(excel_json_value(value), ensure_ascii=False, sort_keys=True)
            elif not (isinstance(value, str) and value.startswith("=")):
                continue
            digest.update(f"{sheet.title}!{cell.coordinate}\0{value}\n".encode("utf-8"))
            count += 1
    return {"formula_cells": count, "formula_sha256": digest.hexdigest()}


def load_book(path: Path, *, data_only: bool = False):
    if not path.is_file():
        die(f"Workbook not found: {path}")
    if path.suffix.lower() not in {".xlsx", ".xlsm"}:
        die("Only .xlsx and .xlsm workbooks are supported.")
    return load_workbook(path, read_only=False, data_only=data_only, keep_vba=path.suffix.lower() == ".xlsm")


def resolve_sheet(book, selector: str):
    if selector.isdigit():
        index = int(selector) - 1
        if not 0 <= index < len(book.worksheets):
            die(f"Sheet number must be between 1 and {len(book.worksheets)}.")
        return book.worksheets[index]
    if selector not in book.sheetnames:
        die(f"Unknown sheet '{selector}'. Available: {', '.join(book.sheetnames)}")
    return book[selector]


def json_out(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2, default=excel_json_value))


def display_value(value: Any, limit: int = 240) -> str:
    text = "" if value is None else str(value)
    return text if len(text) <= limit else text[: limit - 1] + "…"


def worksheet_overview(book) -> dict[str, Any]:
    return {
        "sheet_count": len(book.worksheets),
        "sheets": [
            {
                "number": i,
                "name": sheet.title,
                "state": sheet.sheet_state,
                "max_row": sheet.max_row,
                "max_column": sheet.max_column,
                "merged_ranges": len(sheet.merged_cells.ranges),
                "tables": [table.name for table in sheet.tables.values()],
            }
            for i, sheet in enumerate(book.worksheets, start=1)
        ],
    }


def command_inspect(args) -> None:
    book = load_book(Path(args.workbook))
    json_out(worksheet_overview(book))


def command_sheet(args) -> None:
    book = load_book(Path(args.workbook), data_only=False)
    sheet = resolve_sheet(book, args.sheet)
    max_rows, max_cols = args.rows, args.cols
    cells = []
    definitions = special_formula_ranges(sheet)
    for row in sheet.iter_rows(min_row=1, max_row=min(sheet.max_row, max_rows), max_col=min(sheet.max_column, max_cols)):
        for cell in row:
            if cell.value is not None:
                cells.append(cell_record(cell, definitions))
    json_out({"sheet": sheet.title, "dimensions": sheet.calculate_dimension(), "preview_rows": max_rows, "preview_columns": max_cols, "cells": cells})


def command_range(args) -> None:
    book = load_book(Path(args.workbook), data_only=False)
    sheet = resolve_sheet(book, args.sheet)
    try:
        target = sheet[args.range]
    except ValueError as exc:
        die(f"Invalid range: {exc}")
    values = []
    definitions = special_formula_ranges(sheet)
    if hasattr(target, "coordinate"):
        target = ((target,),)
    for row in target:
        values.append([
            cell_record(cell, definitions)
            for cell in row
        ])
    json_out({"sheet": sheet.title, "range": args.range, "values": values})


# Direct A1 references and ranges. Tokenizing preserves cross-sheet range owners
# and prevents quoted text such as "M30" from being treated as a cell reference.
REF_RE = re.compile(r"(?:[A-Z]{1,3}[1-9][0-9]*(?::[A-Z]{1,3}[1-9][0-9]*)?|[A-Z]{1,3}:[A-Z]{1,3}|[1-9][0-9]*:[1-9][0-9]*)", re.I)


def formula_references(formula: str, current_sheet: str) -> tuple[list[str], list[str]]:
    refs, warnings = [], []
    try:
        tokens = Tokenizer(formula).items
    except Exception as exc:
        return [], [f"Cannot parse formula references: {exc}"]
    for token in tokens:
        if token.type != "OPERAND" or token.subtype != "RANGE":
            continue
        raw = token.value
        sheet_name, address = raw.rsplit("!", 1) if "!" in raw else (current_sheet, raw)
        if sheet_name.startswith("'") and sheet_name.endswith("'"):
            sheet_name = sheet_name[1:-1].replace("''", "'")
        address = address.replace("$", "")
        if "[" in raw or ":" in sheet_name or not REF_RE.fullmatch(address):
            warnings.append(f"Unresolved named, structured, external or 3D reference: {raw}")
            continue
        refs.append(f"{sheet_name}!{address}")
    upper = formula.upper()
    for name in ("INDIRECT", "OFFSET", "[", "!"):
        if name in upper and name in {"INDIRECT", "OFFSET", "["}:
            warnings.append("Formula contains dynamic or external references that cannot be fully traced.")
            break
    return sorted(set(refs)), warnings


def trace_cell(sheet, address: str) -> dict[str, Any]:
    record = cell_record(sheet[address])
    formula = record["formula"]
    refs, warnings = formula_references(formula, sheet.title) if formula else ([], [])
    if record.get("formula_type") == "array":
        warnings.append("Array result cells share the anchor formula; it is not a separate formula in every result cell.")
    if record.get("formula_type") == "data_table":
        warnings.append("Excel data-table definition has no ordinary formula text; input metadata is provided.")
    if record.get("formula_type"):
        warnings.append("Formula text was read from the workbook; this tool does not recalculate it.")
    return {**record, "references": refs, "warnings": warnings}


def command_trace(args) -> None:
    book = load_book(Path(args.workbook), data_only=False)
    if "!" not in args.cell:
        die("Use a fully qualified cell, e.g. 'Workshop!D37'.")
    sheet_name, address = args.cell.rsplit("!", 1)
    sheet = resolve_sheet(book, sheet_name)
    json_out(trace_cell(sheet, address))


def find_header_column(sheet, header_row: int, header: str) -> int:
    matches = [cell.column for cell in sheet[header_row] if str(cell.value).strip() == header]
    if len(matches) != 1:
        die(f"Expected exactly one header '{header}' in row {header_row}; found {len(matches)}.")
    return matches[0]


def read_values(path: Path, id_column: str, value_column: str) -> dict[str, Any]:
    if not path.is_file():
        die(f"Results file not found: {path}")
    rows: list[dict[str, Any]] = []
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
    elif path.suffix.lower() in {".xlsx", ".xlsm"}:
        source = load_book(path, data_only=False)
        sheet = source.active
        headers = [str(cell.value).strip() if cell.value is not None else "" for cell in sheet[1]]
        for raw in sheet.iter_rows(min_row=2, values_only=True):
            rows.append(dict(zip(headers, raw)))
    else:
        die("Results file must be .csv, .xlsx or .xlsm.")
    if not rows or id_column not in rows[0] or value_column not in rows[0]:
        die(f"Results file must contain columns '{id_column}' and '{value_column}'.")
    values: dict[str, Any] = {}
    duplicates = []
    for row in rows:
        key = str(row.get(id_column, "")).strip()
        if not key:
            continue
        if key in values:
            duplicates.append(key)
        values[key] = row.get(value_column)
    if duplicates:
        die("Duplicate IDs in results file: " + ", ".join(sorted(set(duplicates))[:10]))
    return values


def assert_target_safe(sheet, destination_column: int, header_row: int, first_row: int, last_row: int) -> None:
    for anchor, (min_col, min_row, max_col, max_row), _ in special_formula_ranges(sheet):
        if min_col <= destination_column <= max_col and min_row <= last_row and max_row >= header_row:
            die(f"Destination overlaps array/data-table formula range owned by {sheet.title}!{anchor}.")
    if any(str(rng).split(":")[0] == f"{get_column_letter(destination_column)}{header_row}" for rng in sheet.merged_cells.ranges):
        die("Destination header is merged. Choose a normal, unmerged column.")
    occupied = [sheet.cell(row, destination_column).coordinate for row in range(header_row, last_row + 1) if sheet.cell(row, destination_column).value is not None]
    if occupied:
        die("Destination column is not empty. Refusing to overwrite: " + ", ".join(occupied[:8]))


def command_plan_participants(args) -> None:
    workbook_path = Path(args.workbook).resolve()
    book = load_book(workbook_path, data_only=False)
    sheet = resolve_sheet(book, args.sheet)
    id_col = find_header_column(sheet, args.header_row, args.id_header)
    template_col = find_header_column(sheet, args.header_row, args.template_header)
    target_col = column_index_from_string(args.target_column.upper())
    first_row = args.header_row + 1
    last_row = sheet.max_row
    assert_target_safe(sheet, target_col, args.header_row, first_row, last_row)
    incoming = read_values(Path(args.results), args.results_id_column, args.results_value_column)
    workbook_ids: dict[str, int] = {}
    duplicates = []
    for row in range(first_row, last_row + 1):
        key = str(sheet.cell(row, id_col).value or "").strip()
        if not key:
            continue
        if key in workbook_ids:
            duplicates.append(key)
        workbook_ids[key] = row
    if duplicates:
        die("Duplicate IDs in workbook target sheet: " + ", ".join(sorted(set(duplicates))[:10]))
    missing = sorted(set(incoming) - set(workbook_ids))
    if missing:
        die("Result IDs absent from workbook; no plan created: " + ", ".join(missing[:15]))
    edits = [{"cell": f"{sheet.title}!{get_column_letter(target_col)}{args.header_row}", "value": args.new_header, "kind": "header"}]
    for key, value in incoming.items():
        if isinstance(value, SPECIAL_FORMULAS):
            die(f"Result {key} contains an array/data-table formula. Supply its calculated judgement as a value.")
        edits.append({"cell": f"{sheet.title}!{get_column_letter(target_col)}{workbook_ids[key]}", "value": value, "kind": "participant_judgement", "bg_id": key})
    plan = {
        "format": "bosch-excel-agent-plan-v1",
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_workbook": str(workbook_path),
        "source_sha256": sha256(workbook_path),
        "source_formula_fingerprint": formula_fingerprint(book),
        "operation": "fill_existing_empty_participant_column",
        "sheet": sheet.title,
        "header_row": args.header_row,
        "id_header": args.id_header,
        "template_header": args.template_header,
        "template_column": get_column_letter(template_col),
        "target_column": get_column_letter(target_col),
        "copy_style_from": f"{sheet.title}!{get_column_letter(template_col)}",
        "edits": edits,
        "preflight": {"workbook_bg_ids": len(workbook_ids), "incoming_results": len(incoming), "missing_ids": [], "target_cells_confirmed_empty": True},
        "limitations": ["The destination must already be an empty column. This tool deliberately does not insert columns or rewrite unrelated formulas.", "Formula recalculation is delegated to Excel/LibreOffice after opening the output file."],
    }
    out = Path(args.plan).resolve()
    if out.exists() and not args.force:
        die(f"Plan already exists: {out}. Use --force to replace it.")
    out.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    json_out({"plan": str(out), "summary": plan["preflight"], "exact_edits": len(edits), "review_before_apply": True})


def copy_column_presentation(sheet, source_col: int, target_col: int, first_row: int, last_row: int) -> None:
    source_letter, target_letter = get_column_letter(source_col), get_column_letter(target_col)
    sheet.column_dimensions[target_letter].width = sheet.column_dimensions[source_letter].width
    sheet.column_dimensions[target_letter].hidden = sheet.column_dimensions[source_letter].hidden
    for row in range(first_row, last_row + 1):
        source, target = sheet.cell(row, source_col), sheet.cell(row, target_col)
        target._style = copy(source._style)
        target.number_format = source.number_format
        target.font = copy(source.font)
        target.fill = copy(source.fill)
        target.border = copy(source.border)
        target.alignment = copy(source.alignment)
        target.protection = copy(source.protection)


def split_qualified(address: str) -> tuple[str, str]:
    if "!" not in address:
        die(f"Plan cell must be sheet-qualified: {address}")
    sheet, cell = address.rsplit("!", 1)
    return sheet, cell


def command_apply(args) -> None:
    plan_path = Path(args.plan).resolve()
    if not plan_path.is_file():
        die(f"Plan not found: {plan_path}")
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    source = Path(args.workbook).resolve()
    output = Path(args.output).resolve()
    if source == output:
        die("Output must be a new file. The source workbook is never overwritten.")
    if plan.get("source_sha256") != sha256(source):
        die("Workbook changed after planning. Create and review a new plan before writing.")
    if output.exists() and not args.force:
        die(f"Output already exists: {output}. Use --force only after reviewing it.")
    book = load_book(source, data_only=False)
    if plan.get("source_formula_fingerprint") != formula_fingerprint(book):
        die("Formula validation changed. Recreate the plan with this version before applying it.")
    sheet = resolve_sheet(book, plan["sheet"])
    target_col = column_index_from_string(plan["target_column"])
    template_col = column_index_from_string(plan["template_column"])
    first_row, last_row = plan["header_row"], sheet.max_row
    assert_target_safe(sheet, target_col, plan["header_row"], first_row, last_row)
    copy_column_presentation(sheet, template_col, target_col, first_row, last_row)
    for edit in plan["edits"]:
        sheet_name, address = split_qualified(edit["cell"])
        if sheet_name != sheet.title:
            die("Cross-sheet edits are not allowed in a participant-column plan.")
        from openpyxl.utils.cell import coordinate_from_string
        column, row = coordinate_from_string(address)
        if column_index_from_string(column) != target_col or not first_row <= row <= last_row:
            die("Edit is outside the reviewed target column/range.")
        if isinstance(edit["value"], str) and edit["value"].startswith("="):
            die("Participant values must not introduce formulas.")
        sheet[address].value = edit["value"]
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix.lower() != source.suffix.lower():
        die("Output extension must match the source workbook (including macros).")
    temporary = output.with_name("." + output.stem + "." + uuid.uuid4().hex + output.suffix)
    try:
        book.save(temporary)
        book.close()
        verification = verify_plan(temporary, plan)
        if not verification["ok"]:
            die("Staged output failed verification; destination was not changed: " + "; ".join(verification["errors"]))
        if sha256(source) != plan["source_sha256"]:
            die("Source changed during saving. Review a new plan.")
        if args.force:
            if output.exists():
                from shutil import copy2
                copy2(output, output.with_name(output.name + "." + uuid.uuid4().hex + ".bak"))
            os.replace(temporary, output)
        else:
            # Atomic publication without overwriting a concurrently created file.
            os.link(temporary, output)
    finally:
        book.close()
        temporary.unlink(missing_ok=True)
    json_out({"output": str(output), "verification": verification, "source_unchanged_sha256": sha256(source) == plan["source_sha256"]})


def verify_plan(workbook: Path, plan: dict[str, Any]) -> dict[str, Any]:
    book = load_book(workbook, data_only=False)
    errors = []
    checked = 0
    for edit in plan["edits"]:
        sheet_name, address = split_qualified(edit["cell"])
        actual = book[sheet_name][address].value
        if actual != edit["value"]:
            errors.append(f"{edit['cell']}: expected {edit['value']!r}, found {actual!r}")
        checked += 1
    actual_formula_fingerprint = formula_fingerprint(book)
    expected_formula_fingerprint = plan.get("source_formula_fingerprint")
    if expected_formula_fingerprint and actual_formula_fingerprint != expected_formula_fingerprint:
        errors.append("Formula locations or formula text changed outside the reviewed value edits.")
    book.close()
    return {"ok": not errors, "checked_cells": checked, "formula_fingerprint": actual_formula_fingerprint, "errors": errors}


def command_verify(args) -> None:
    plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
    json_out(verify_plan(Path(args.workbook), plan))


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(description="Coordinate-accurate Excel reader and safe participant-column writer")
    commands = root.add_subparsers(dest="command", required=True)
    for name, func in (("inspect", command_inspect), ("sheet", command_sheet), ("range", command_range), ("trace", command_trace), ("apply", command_apply), ("verify", command_verify)):
        sub = commands.add_parser(name)
        sub.set_defaults(func=func)
        sub.add_argument("workbook")
        if name == "sheet":
            sub.add_argument("--sheet", required=True)
            sub.add_argument("--rows", type=int, default=40)
            sub.add_argument("--cols", type=int, default=20)
        elif name == "range":
            sub.add_argument("--sheet", required=True)
            sub.add_argument("--range", required=True)
        elif name == "trace":
            sub.add_argument("--cell", required=True)
        elif name in {"apply", "verify"}:
            sub.add_argument("--plan", required=True)
            if name == "apply":
                sub.add_argument("--output", required=True)
                sub.add_argument("--force", action="store_true")
    sub = commands.add_parser("plan-participants")
    sub.set_defaults(func=command_plan_participants)
    sub.add_argument("workbook")
    sub.add_argument("--sheet", required=True)
    sub.add_argument("--header-row", required=True, type=int)
    sub.add_argument("--id-header", required=True)
    sub.add_argument("--template-header", required=True)
    sub.add_argument("--target-column", required=True)
    sub.add_argument("--new-header", required=True)
    sub.add_argument("--results", required=True)
    sub.add_argument("--results-id-column", required=True)
    sub.add_argument("--results-value-column", required=True)
    sub.add_argument("--plan", required=True)
    sub.add_argument("--force", action="store_true")
    return root


def main() -> None:
    args = parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

# Recommended workflow for an existing complex Excel file (run in this folder):
# 1) Inspect workbook structure and locate the correct Sheet:
#    python excel_agent.py inspect "C:\\path\\to\\workbook.xlsx"
# 2) Read an exact region including cell coordinates and formulas:
#    python excel_agent.py range "C:\\path\\to\\workbook.xlsx" --sheet "Workshop" --range "A1:Z40"
# 3) Trace direct formula references of one exact cell:
#    python excel_agent.py trace "C:\\path\\to\\workbook.xlsx" --cell "Workshop!D37"
# 4) Create (but do not apply) a reviewable plan. Target column must already be empty:
#    python excel_agent.py plan-participants "C:\\path\\to\\workbook.xlsx" --sheet "Workshop" --header-row 1 --id-header "BG-ID" --template-header "Jonas" --target-column "M" --new-header "Berk" --results "C:\\path\\to\\berk_results.xlsx" --results-id-column "BG-ID" --results-value-column "Judgement" --plan "C:\\path\\to\\berk_plan.json"
# 5) Review berk_plan.json. Only then create a NEW workbook and verify every planned cell:
#    python excel_agent.py apply "C:\\path\\to\\workbook.xlsx" --plan "C:\\path\\to\\berk_plan.json" --output "C:\\path\\to\\workbook_with_berk.xlsx"
# 6) Re-run an independent verification at any time:
#    python excel_agent.py verify "C:\\path\\to\\workbook_with_berk.xlsx" --plan "C:\\path\\to\\berk_plan.json"
# 7) Inspect array formulas, including their anchor and covered range:
#    python excel_agent.py trace "C:\Users\wdu4fel\Documents\Python_Projects\整理129BG资料\129BG.xlsx" --cell "Klassifikation_Übersicht_Gesamt!M30"
#    python excel_agent.py range "C:\Users\wdu4fel\Documents\Python_Projects\整理129BG资料\129BG.xlsx" --sheet "Klassifikation_Übersicht_Gesamt" --range "M30:Y30"

